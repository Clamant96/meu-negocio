package org.helpconnect.meuNegocio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeuNegocioApplicationTests {

	@Test
	void contextLoads() {
	}

}
